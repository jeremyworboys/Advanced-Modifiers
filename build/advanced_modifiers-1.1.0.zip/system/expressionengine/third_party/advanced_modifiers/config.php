<?php

if (!defined('ADVANCED_MODIFIERS_VERSION')) {
    define('ADVANCED_MODIFIERS_NAME', 'Advanced Modifiers');
    define('ADVANCED_MODIFIERS_VERSION', '1.1.0');
}

$config['name'] = ADVANCED_MODIFIERS_NAME;
$config['version'] = ADVANCED_MODIFIERS_VERSION;
$config['nsm_addon_updater']['versions_xml'] = 'http://complexcompulsions.com/add-ons/advanced-modifiers/release-feed/';
